# jquery.mb.YTPlayer

__An open source jQuery component to easily build your custom Youtube® player or to use a Youtube® video as background for your page.__

![mb.YTPlayer](http://pupunzi.open-lab.com/wp-content/uploads/2010/06/DSC03762.jpg)

## [go to the demo](http://pupunzi.com/#mb.components/mb.YTPlayer/YTPlayer.html)
## [go to the doc](http://wiki.github.com/pupunzi/jquery.mb.YTPlayer/)
## [go to the blog](http://pupunzi.open-lab.com/mb-jquery-components/jquery-mb-YTPlayer/)


[jquery.mb.components](http://pupunzi.com/), another way of thinking the web
